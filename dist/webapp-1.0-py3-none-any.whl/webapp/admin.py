from django.contrib import admin
from .models import Offer
# Register your models here.
admin.site.register(Offer)